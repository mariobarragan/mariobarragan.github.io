SAVE THIS FILE AS A INFO.HTML
inside of /home/mb/html
<?php
phpinfo();
?>
