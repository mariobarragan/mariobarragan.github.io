<html>
<body>

<?php
echo "<p>";
   echo "e = ir ";
   echo "<hr />"; 
   $i = 2;
   $r = 17;
   echo "i = $i and r = $r";
   echo "<br />";
   echo "e =  ";
   $e = $i * $r; 
   echo "$e";
echo "</p>"; 
?>

</body>
</html>
